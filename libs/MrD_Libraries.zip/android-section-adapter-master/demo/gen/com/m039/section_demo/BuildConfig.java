/** Automatically generated file. DO NOT MODIFY */
package com.m039.section_demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}