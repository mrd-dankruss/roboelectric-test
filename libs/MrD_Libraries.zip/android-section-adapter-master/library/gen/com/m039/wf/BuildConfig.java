/** Automatically generated file. DO NOT MODIFY */
package com.m039.wf;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}